#! /bin/bash
# chmod +x -> give script execution rights

echo "Starting Server..."
# -d --> detach mode: useful when you want to execute commands in same terminal 
# --build --> changes in pipenv file? build container from scratch
sudo docker-compose up -d --build

# migrate database 
# only possible to work in the database itself if the container is running
# -> run commands from inside of the container 
echo "Makemigrations..."
sudo docker-compose exec web python manage.py makemigrations 
echo "Migrating..."
sudo docker-compose exec web python manage.py migrate

# create superuser
# only if its the first time setting up the server
# echo "Creating Superuser..."
# sudo docker-compose exec web python manage.py createsuperuser

# show list of active docker processes
echo "Current Docker processes..."
sudo docker ps -a
