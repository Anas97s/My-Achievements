#! /bin/bash
# chmod +x -> give script execution rights

echo "Stopping Server..."
# -d --> detach mode: useful when you want to execute commands in same terminal 
# --build --> changes in pipenv file? build container from scratch
sudo docker-compose down
