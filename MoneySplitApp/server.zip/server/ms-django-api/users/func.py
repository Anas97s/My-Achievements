class Func():
    def validate_decimals(value):
        try:
            return round(float(value), 2)
        except:
            raise ValidationError(
                _('%(value)s is not an integer or a float  number'),
                params={'value': value},
            )
