from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.
class Image(models.Model):
    i_id = models.AutoField(primary_key=True)
    image = models.ImageField(upload_to='images', blank=True)


class User(AbstractUser):
    email = models.CharField(max_length=255, unique=True)
    password = models.CharField(max_length=255)
    username = models.CharField(max_length=255, default=None, blank=True, null=True)
    paypalme = models.CharField(max_length=255, default=None, blank=True, null=True)
    i_id = models.ForeignKey(Image, on_delete=models.CASCADE, db_column='i_id', null=True, default=None, blank=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []


class Event(models.Model):
    v_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    due_date = models.DateField(default=None, null=True)
    done = models.BooleanField(default=False)
    i_id = models.ForeignKey(Image, on_delete=models.CASCADE, db_column='i_id', null=True, default=None, blank=True)


class Post(models.Model):
    p_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)
    amount = models.FloatField(default=0.00)
    description = models.CharField(max_length=500, default=None, blank=True, null=True)
    creation_date = models.DateField(default=None, null=True)
    i_id = models.ForeignKey(Image, on_delete=models.CASCADE, db_column='i_id', null=True, default=None, blank=True)


class Right(models.Model):
    r_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=255)


class hasEventRights(models.Model):
    r_id = models.ForeignKey(Right, on_delete=models.CASCADE, db_column='r_id')
    v_id = models.ForeignKey(Event, on_delete=models.CASCADE, db_column='v_id')
    email = models.ForeignKey(User, on_delete=models.CASCADE, db_column='email')

    class Meta:
        unique_together = (("r_id", "v_id", "email"),)


class hasItemRights(models.Model):
    r_id = models.ForeignKey(Right, on_delete=models.CASCADE, db_column='r_id')
    p_id = models.ForeignKey(Post, on_delete=models.CASCADE, db_column='p_id')
    email = models.ForeignKey(User, on_delete=models.CASCADE, db_column='email')

    class Meta:
        unique_together = (("r_id", "p_id", "email"),)


class Owns(models.Model):
    v_id = models.ForeignKey(Event, on_delete=models.CASCADE, db_column='v_id')
    p_id = models.ForeignKey(Post, on_delete=models.CASCADE, db_column='p_id')

    class Meta:
        unique_together = (("p_id", "v_id"),)


class News(models.Model):
    n_id = models.AutoField(primary_key=True)


class NewsType(models.Model):
    nt_id = models.AutoField(primary_key=True)
    type = models.CharField(max_length=255)


class hasNewsType(models.Model):
    n_id = models.ForeignKey(News, on_delete=models.CASCADE, db_column='n_id')
    nt_id = models.ForeignKey(NewsType, on_delete=models.CASCADE, db_column='nt_id')

    class Meta:
        unique_together = (("n_id", "nt_id"),)


class hasUserNews(models.Model):
    email = models.ForeignKey(User, on_delete=models.CASCADE, db_column='email')
    n_id = models.ForeignKey(News, on_delete=models.CASCADE, db_column='n_id')

    class Meta:
        unique_together = (("email", "n_id"),)


class isEventNews(models.Model):
    n_id = models.ForeignKey(News, on_delete=models.CASCADE, db_column='n_id')
    v_id = models.ForeignKey(Event, on_delete=models.CASCADE, db_column='v_id')

    class Meta:
        unique_together = (("n_id", "v_id"),)


class isPostNews(models.Model):
    n_id = models.ForeignKey(News, on_delete=models.CASCADE, db_column='n_id')
    p_id = models.ForeignKey(Post, on_delete=models.CASCADE, db_column='p_id')

    class Meta:
        unique_together = (("n_id", "p_id"),)
