from rest_framework import serializers
from .models import User
from .models import Event
from .models import Post
from .models import Right
from .models import hasEventRights
from .models import hasItemRights
from .models import Owns
from .models import News
from .models import NewsType
from .models import hasNewsType
from .models import hasUserNews
from .models import isPostNews
from .models import isEventNews
from .models import Image


class ImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = Image
        fields = ['i_id', 'image']


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'password', 'paypalme', 'i_id']
        extra_kwargs = {
            'password': {'write_only': True}
        }

    def create(self, validated_data):
        password = validated_data.pop('password', None)
        instance = self.Meta.model(**validated_data)
        if password is not None:
            instance.set_password(password)
        instance.save()
        return instance


class EventSerializer(serializers.ModelSerializer):
    class Meta:
        model = Event
        fields = ['v_id', 'name', 'due_date', 'done', 'i_id']


class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = ['p_id', 'name', 'amount', 'description', 'creation_date', 'i_id']


class RightSerializer(serializers.ModelSerializer):
    class Meta:
        model = Right
        fields = ['r_id', 'name']


class UserRightsEventSerializer(serializers.ModelSerializer):
    class Meta:
        model = hasEventRights
        fields = ['r_id', 'v_id', 'email']


class UserRightsItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = hasItemRights
        fields = ['r_id', 'p_id', 'email']


class OwnsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Owns
        fields = ['p_id', 'v_id']


class NewsSerializer(serializers.ModelSerializer):
    n_id = serializers.IntegerField(required=False)

    class Meta:
        model = News
        fields = ['n_id']


class NewsTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewsType
        fields = ['nt_id', 'type']


class hasNewsTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = hasNewsType
        fields = ['nt_id', 'n_id']


class hasUserNewsSerializer(serializers.ModelSerializer):
    class Meta:
        model = hasUserNews
        fields = ['email', 'n_id']


class isPostNewsSerializer(serializers.ModelSerializer):
    class Meta:
        model = isPostNews
        fields = ['n_id', 'p_id']


class isEventNewsSerializer(serializers.ModelSerializer):
    class Meta:
        model = isEventNews
        fields = ['n_id', 'v_id']
