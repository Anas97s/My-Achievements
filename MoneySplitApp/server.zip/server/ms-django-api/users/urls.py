from django.urls import path
from .views import RegisterView
from .views import LoginView
from .views import UserView
from .views import LogoutView
from .views import CreateEventView
from .views import ChangeEventView
from .views import DeleteEventView
from .views import CreatePostView
from .views import ChangePostView
from .views import DeletePostView
from .views import AddUserToEventView
from .views import GetAllEventsView
from .views import ChangeUsernameView
from .views import ChangePasswordView
from .views import AddUserToPostView
from .views import GetUserNewsView
from .views import RemoveUserFromEventView
from .views import ChangePaypalMeView
from .views import DeletePaypalMeView
from .views import GetPaypalMeView
from .views import CreatePaymentView
from .views import GetAllPaymentsView
from .views import DeleteNewsView
from .views import SetProfilePictureView
from .views import GetProfilePictureView


urlpatterns = [
    path('register', RegisterView.as_view()),
    path('login', LoginView.as_view()),
    path('user', UserView.as_view()),
    path('logout', LogoutView.as_view()),
    path('create_event', CreateEventView.as_view()),
    path('change_event', ChangeEventView.as_view()),
    path('delete_event', DeleteEventView.as_view()),
    path('create_post', CreatePostView.as_view()),
    path('change_post', ChangePostView.as_view()),
    path('delete_post', DeletePostView.as_view()),
    path('add_user_to_event', AddUserToEventView.as_view()),
    path('get_all_events', GetAllEventsView.as_view()),
    path('change_username', ChangeUsernameView.as_view()),
    path('change_password', ChangePasswordView.as_view()),
    path('add_user_to_post', AddUserToPostView.as_view()),
    path('get_user_news', GetUserNewsView.as_view()),
    path('remove_user_from_event', RemoveUserFromEventView.as_view()),
    path('change_paypalme', ChangePaypalMeView.as_view()),
    path('delete_paypalme', DeletePaypalMeView.as_view()),
    path('get_paypalme', GetPaypalMeView.as_view()),
    path('create_payment', CreatePaymentView.as_view()),
    path('get_all_payments', GetAllPaymentsView.as_view()),
    path('delete_news', DeleteNewsView.as_view()),
    path('set_profile_picture', SetProfilePictureView.as_view()),
    path('get_profile_picture', GetProfilePictureView.as_view()),
]



