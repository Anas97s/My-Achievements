from rest_framework.decorators import renderer_classes, api_view
from rest_framework.renderers import TemplateHTMLRenderer, JSONRenderer
from rest_framework.schemas import openapi
from drf_yasg import openapi
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.exceptions import AuthenticationFailed
from rest_framework.parsers import MultiPartParser
from rest_framework.parsers import FormParser
import jwt
import datetime
from drf_yasg.utils import swagger_auto_schema
from .serializers import UserSerializer
from .serializers import EventSerializer
from .serializers import PostSerializer
from .serializers import RightSerializer
from .serializers import UserRightsEventSerializer
from .serializers import UserRightsItemSerializer
from .serializers import OwnsSerializer
from .serializers import NewsSerializer
from .serializers import NewsTypeSerializer
from .serializers import hasNewsTypeSerializer
from .serializers import hasUserNewsSerializer
from .serializers import isPostNewsSerializer
from .serializers import isEventNewsSerializer
from .serializers import ImageSerializer
from .models import User
from .models import Event
from .models import Post
from .models import Right
from .models import hasEventRights
from .models import hasItemRights
from .models import Owns
from .models import News
from .models import NewsType
from .models import hasNewsType
from .models import hasUserNews
from .models import isPostNews
from .models import isEventNews
from .models import Image
from django.db.models import Max
from django.http import HttpResponse


# Create your views here.


class RegisterView(APIView):
    @swagger_auto_schema(request_body=UserSerializer, responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'id': openapi.Schema(type=openapi.TYPE_INTEGER),
                'username': openapi.Schema(type=openapi.TYPE_STRING),
                'email': openapi.Schema(type=openapi.TYPE_STRING)
            }
        }
    )})
    def post(self, request):
        serializer = UserSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)


class ChangePaypalMeView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'paypalme': openapi.Schema(type=openapi.TYPE_STRING),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING),
                'paypalme': openapi.Schema(type=openapi.TYPE_STRING),
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        user = User.objects.filter(id=payload['id']).first()
        response = Response()
        user.paypalme = request.data['paypalme']
        user.save()

        response.data = {
            'message': 'PaypalMe changed successfully',
            'username': request.data['paypalme']
        }

        return response


class DeletePaypalMeView(APIView):
    @swagger_auto_schema(responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING)
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        user = User.objects.filter(id=payload['id']).first()
        response = Response()
        user.paypalme = None
        user.save()

        response = Response()

        response.data = {
            'message': 'success'
        }

        return response


class GetPaypalMeView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'email': openapi.Schema(type=openapi.TYPE_STRING),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'paypalme': openapi.Schema(type=openapi.TYPE_STRING),
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        user = User.objects.filter(email=request.data['email']).first()
        serializer = UserSerializer(user)

        response = Response()
        response.data = {
            'paypalme': serializer.data['paypalme']
        }

        return response


class LoginView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'email': openapi.Schema(type=openapi.TYPE_STRING),
            'password': openapi.Schema(type=openapi.TYPE_STRING),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING),
                'jwt': openapi.Schema(type=openapi.TYPE_STRING)
            }
        }
    )})
    def post(self, request):
        email = request.data['email']
        password = request.data['password']

        user = User.objects.filter(email=email).first()
        if user is None:
            raise AuthenticationFailed('User not found!')
        if not user.check_password(password):
            raise AuthenticationFailed('Incorrect password')

        payload = {
            'id': user.id,
            'username': user.username,
            'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=60),
            'iat': datetime.datetime.utcnow()
        }

        token = jwt.encode(payload, 'secret', algorithm='HS256').encode().decode('utf-8')

        response = Response()
        response.set_cookie(key='jwt', value=token, httponly=True)
        response.data = {
            'message': 'success',
            'jwt': token

        }
        return response


class UserView(APIView):
    @swagger_auto_schema(responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'id': openapi.Schema(type=openapi.TYPE_INTEGER),
                'username': openapi.Schema(type=openapi.TYPE_STRING),
                'email': openapi.Schema(type=openapi.TYPE_STRING),
                'paypalme': openapi.Schema(type=openapi.TYPE_STRING)
            }
        }
    )})
    def get(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        user = User.objects.filter(id=payload['id']).first()
        serializer = UserSerializer(user)
        return Response(serializer.data)


class ChangeUsernameView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'new_username': openapi.Schema(type=openapi.TYPE_STRING),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING),
                'username': openapi.Schema(type=openapi.TYPE_STRING),
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        user = User.objects.filter(id=payload['id']).first()
        response = Response()
        user.username = request.data['new_username']
        user.save()

        response.data = {
            'message': 'Username changed successfully',
            'username': request.data['new_username']
        }

        return response


class ChangePasswordView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'password': openapi.Schema(type=openapi.TYPE_STRING),
            'new_password': openapi.Schema(type=openapi.TYPE_STRING),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING),
                'username': openapi.Schema(type=openapi.TYPE_STRING),
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        user = User.objects.filter(id=payload['id']).first()
        response = Response()

        if (user.check_password(request.data['password'])):
            user.set_password(request.data['new_password'])
            user.save()

            response.data = {
                'message': 'Password changed successfully'
            }
        else:
            response.data = {
                'message': 'wrong password!'
            }
        return response


class LogoutView(APIView):
    @swagger_auto_schema(responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING)
            }
        }
    )})
    def post(self, request):
        response = Response()
        response.delete_cookie('jwt')
        response.data = {
            'message': 'success'
        }
        return response


class CreateEventView(APIView):
    @swagger_auto_schema(request_body=EventSerializer, responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'email': openapi.Schema(type=openapi.TYPE_STRING),
                'r_id': openapi.Schema(type=openapi.TYPE_INTEGER),
                'name': openapi.Schema(type=openapi.TYPE_STRING),
                'v_id': openapi.Schema(type=openapi.TYPE_INTEGER)
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        user = User.objects.filter(id=payload['id']).first()
        userserializer = UserSerializer(user)

        eventdata = {
            'name': request.data['name'],
            'due_date': request.data['due_date']
        }
        eventserializer = EventSerializer(data=eventdata)
        eventserializer.is_valid(raise_exception=True)
        eventserializer.save()
        event = eventserializer.data

        user_rights_event_data = {
            'email': userserializer.data['id'],
            'r_id': 1,
            'v_id': event['v_id']
        }
        user_rights_event_serializer = UserRightsEventSerializer(data=user_rights_event_data)
        user_rights_event_serializer.is_valid(raise_exception=True)
        user_rights_event_serializer.save()

        response = Response()
        response.data = {
            'email': userserializer.data['email'],
            'r_id': 1,
            'name': event['name'],
            'v_id': event['v_id'],
            'due_date': event['due_date']
        }
        return response


class ChangeEventView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'v_id': openapi.Schema(type=openapi.TYPE_INTEGER),
            'name': openapi.Schema(type=openapi.TYPE_STRING),
            'due_date': openapi.Schema(type=openapi.TYPE_STRING),
            'done': openapi.Schema(type=openapi.TYPE_BOOLEAN)
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING),
                'name': openapi.Schema(type=openapi.TYPE_STRING),
            }
        }
    )})
    def put(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        v_id = request.data['v_id']
        name = request.data['name']
        due_date = request.data['due_date']
        done = request.data['done']

        user = User.objects.filter(id=payload['id']).first()
        userserializer = UserSerializer(user)

        userrights = hasEventRights.objects.filter(email=userserializer.data['id'], v_id=v_id).first()
        user_rights_event_serializer = UserRightsEventSerializer(userrights)

        response = Response()

        if user_rights_event_serializer.data['r_id'] == 1:
            event = Event.objects.get(v_id=v_id)
            event.name = name
            event.due_date = due_date
            event.done = done
            event.save()
            response.data = {
                'message': 'success',
                'name': request.data['name'],
                'due_date': request.data['due_date'],
                'done': request.data['done']
            }
        else:
            response.data = {
                'message': 'u can`t change this Event'
            }

        return response


class AddUserToEventView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'v_id': openapi.Schema(type=openapi.TYPE_INTEGER),
            'email': openapi.Schema(type=openapi.TYPE_STRING),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING),
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        v_id = request.data['v_id']
        email = request.data['email']

        user = User.objects.filter(email=email).first()
        userserializer = UserSerializer(user)

        user_rights_event_data = {
            'email': userserializer.data['id'],
            'r_id': 2,
            'v_id': v_id
        }

        response = Response()

        # check if current user is in event
        current_user = hasEventRights.objects.filter(email=payload['id'], v_id=v_id).first()
        if not current_user:
            response.data = {
                'message': 'Permission denied!'
            }
            return response

        # checking if user is already in event
        existing_user = hasEventRights.objects.filter(email=userserializer.data['id'], v_id=v_id).first()
        if not existing_user:
            user_rights_event_serializer = UserRightsEventSerializer(data=user_rights_event_data)
            user_rights_event_serializer.is_valid(raise_exception=True)
            user_rights_event_serializer.save()

            # creating new news for user
            """news_serializer = NewsSerializer(data={})
            news_serializer.is_valid(raise_exception=True)
            news = news_serializer.save()

            n_id = news.n_id"""
            max_n_id = News.objects.all().aggregate(Max('n_id'))['n_id__max']
            if max_n_id is None:
                next_n_id = 1
            else:
                next_n_id = max_n_id + 1

            data = {'n_id': next_n_id}
            news_serializer = NewsSerializer(data=data)
            news_serializer.is_valid(raise_exception=True)
            news_serializer.save()

            n_id = News.objects.get(pk=news_serializer.data['n_id']).n_id

            # add to hasUserNews
            email = userserializer.data['id']
            hasusernews_data = {
                "n_id": n_id,
                "email": email,
            }

            hasusernews_serializer = hasUserNewsSerializer(data=hasusernews_data)
            hasusernews_serializer.is_valid(raise_exception=True)
            hasusernews_serializer.save()

            # add to isEventNews
            iseventnews_data = {
                "n_id": n_id,
                "v_id": v_id,
            }
            iseventnews_serializer = isEventNewsSerializer(data=iseventnews_data)
            iseventnews_serializer.is_valid(raise_exception=True)
            iseventnews_serializer.save()

            # add hasNewsType
            # news type 1 == event_invitation
            nt_id = 1
            hasnewstype_data = {
                'nt_id': nt_id,
                'n_id': n_id,
            }

            hasnewstype_serializer = hasNewsTypeSerializer(data=hasnewstype_data)
            hasnewstype_serializer.is_valid(raise_exception=True)
            hasnewstype_serializer.save()

            response.data = {
                'message': 'success',
                'email': request.data['email']
            }
        else:
            response.data = {
                'message': 'Can not add user to event. User is already in event.'
            }

        return response


class RemoveUserFromEventView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'v_id': openapi.Schema(type=openapi.TYPE_INTEGER),
            'email': openapi.Schema(type=openapi.TYPE_STRING),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING),
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')
        v_id = request.data['v_id']

        user = User.objects.filter(id=payload['id']).first()
        userserializer = UserSerializer(user)

        remove_user = User.objects.filter(email=request.data['email']).first()
        remove_userserializer = UserSerializer(remove_user)

        userrights = hasEventRights.objects.filter(email=userserializer.data['id'], v_id=v_id).first()
        user_rights_event_serializer = UserRightsEventSerializer(userrights)

        # leave event only if you are not the owner of an event
        #

        response = Response()

        if remove_userserializer.data['email'] == userserializer.data['email'] and user_rights_event_serializer.data[
            'r_id'] == 1:
            response.data = {
                'message': 'you are the owner. you can\'t remove yourself'
            }
        elif user_rights_event_serializer.data['r_id'] != 1 and remove_userserializer.data['email'] == \
                userserializer.data['email']:
            remove_user_right = hasEventRights.objects.filter(email=remove_userserializer.data['id'], v_id=v_id).first()
            remove_user_right.delete()
            response.data = {
                'message': 'success'
            }
        elif user_rights_event_serializer.data['r_id'] == 1:
            remove_user_right = hasEventRights.objects.filter(email=remove_userserializer.data['id'], v_id=v_id).first()
            remove_user_right.delete()
            response.data = {
                'message': 'success'
            }
        else:
            response.data = {
                'message': 'u can\'t remove this user'
            }

        return response


class DeleteEventView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'v_id': openapi.Schema(type=openapi.TYPE_INTEGER),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING)
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        v_id = request.data['v_id']

        user = User.objects.filter(id=payload['id']).first()
        userserializer = UserSerializer(user)

        userrights = hasEventRights.objects.filter(email=userserializer.data['id'], v_id=v_id).first()
        user_rights_event_serializer = UserRightsEventSerializer(userrights)

        response = Response()

        if user_rights_event_serializer.data['r_id'] == 1:
            post_data_set = Owns.objects.all().filter(v_id=v_id)
            for post_data in post_data_set:
                ownserializer = OwnsSerializer(post_data)
                p_id = ownserializer.data['p_id']
                post = Post.objects.get(p_id=p_id)
                post.delete()

            event = Event.objects.get(v_id=v_id)
            event.delete()
            response.data = {
                'message': 'success'
            }
        else:
            response.data = {
                'message': 'u can`t delete this Event'
            }

        return response


# 'user_ids': openapi.Schema(items=openapi.Items(type=openapi.TYPE_INTEGER), type=openapi.TYPE_ARRAY),
class CreatePostView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'name': openapi.Schema(type=openapi.TYPE_STRING),
            'amount': openapi.Schema(type=openapi.TYPE_NUMBER),
            'description': openapi.Schema(type=openapi.TYPE_STRING),
            'v_id': openapi.Schema(type=openapi.TYPE_INTEGER),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'p_id': openapi.Schema(type=openapi.TYPE_INTEGER),
                'name': openapi.Schema(type=openapi.TYPE_STRING),
                'amount': openapi.Schema(type=openapi.TYPE_NUMBER),
                'description': openapi.Schema(type=openapi.TYPE_STRING),
                'creation_date': openapi.Schema(type=openapi.TYPE_STRING)
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        post_data = {
            'name': request.data['name'],
            'amount': request.data['amount'],
            'description': request.data['description'],
            'creation_date': datetime.date.today()
        }
        post_serializer = PostSerializer(data=post_data)
        post_serializer.is_valid(raise_exception=True)
        post_serializer.save()

        p_id = post_serializer.data['p_id']

        owns_data = {
            "p_id": p_id,
            "v_id": request.data['v_id']
        }
        owns_serializer = OwnsSerializer(data=owns_data)
        owns_serializer.is_valid(raise_exception=True)
        owns_serializer.save()

        user_rights_item_data = {
            "email": payload['id'],
            "p_id": p_id,
            "r_id": 1
        }
        user_rights_item_serializer = UserRightsItemSerializer(data=user_rights_item_data)
        user_rights_item_serializer.is_valid(raise_exception=True)
        user_rights_item_serializer.save()
        """
        for user_id in request.data['user_ids']:
            user_rights_item_data = {
                "email": user_id,
                "p_id": p_id,
                "r_id": 2
            }
            user_rights_item_serializer = UserRightsItemSerializer(data=user_rights_item_data)
            user_rights_item_serializer.is_valid(raise_exception=True)
            user_rights_item_serializer.save()
        """
        response = Response()
        response.data = {
            'p_id': p_id,
            'name': request.data['name'],
            'amount': request.data['amount'],
            'description': request.data['description'],
            'creation_date': datetime.date.today()

        }
        return response


class ChangePostView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'p_id': openapi.Schema(type=openapi.TYPE_INTEGER),
            'name': openapi.Schema(type=openapi.TYPE_STRING),
            'amount': openapi.Schema(type=openapi.TYPE_NUMBER, default=0.0),
            'description': openapi.Schema(type=openapi.TYPE_STRING),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING),
            }
        }
    )})
    def put(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')
        serializer = PostSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        p_id = request.data['p_id']
        name = request.data['name']
        amount = request.data['amount']
        description = request.data['description']
        post = Post.objects.get(p_id=p_id)
        post.name = name
        post.amount = amount
        post.description = description
        post.save()
        response = Response()
        response.data = {
            'message': 'success'
        }
        return response


class AddUserToPostView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'p_id': openapi.Schema(type=openapi.TYPE_INTEGER),
            'email': openapi.Schema(type=openapi.TYPE_STRING),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING),
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        p_id = request.data['p_id']
        email = request.data['email']

        user = User.objects.filter(email=email).first()
        userserializer = UserSerializer(user)

        user_rights_post_data = {
            'email': userserializer.data['id'],
            'r_id': 2,
            'p_id': p_id
        }

        response = Response()

        # check if current user is in post
        current_user = hasItemRights.objects.filter(email=payload['id'], p_id=p_id).first()
        if not current_user:
            response.data = {
                'message': 'Permission denied!'
            }
            return response

        # checking if user is already in post
        existing_user = hasItemRights.objects.filter(email=userserializer.data['id'], p_id=p_id).first()
        if not existing_user:
            user_rights_item_serializer = UserRightsItemSerializer(data=user_rights_post_data)
            user_rights_item_serializer.is_valid(raise_exception=True)
            user_rights_item_serializer.save()

            # creating new news for user
            max_n_id = News.objects.all().aggregate(Max('n_id'))['n_id__max']
            if max_n_id is None:
                next_n_id = 1
            else:
                next_n_id = max_n_id + 1

            data = {'n_id': next_n_id}
            news_serializer = NewsSerializer(data=data)
            news_serializer.is_valid(raise_exception=True)
            news_serializer.save()

            n_id = News.objects.get(pk=news_serializer.data['n_id']).n_id

            # add to hasUserNews
            email = userserializer.data['id']
            hasusernews_data = {
                "n_id": n_id,
                "email": email,
            }

            hasusernews_serializer = hasUserNewsSerializer(data=hasusernews_data)
            hasusernews_serializer.is_valid(raise_exception=True)
            hasusernews_serializer.save()

            # add to isPostNews
            ispostnews_data = {
                "n_id": n_id,
                "p_id": p_id,
            }
            ispostnews_serializer = isPostNewsSerializer(data=ispostnews_data)
            ispostnews_serializer.is_valid(raise_exception=True)
            ispostnews_serializer.save()

            # add hasNewsType
            # news type 3 == post
            nt_id = 3
            hasnewstype_data = {
                'nt_id': nt_id,
                'n_id': n_id,
            }
            hasnewstype_serializer = hasNewsTypeSerializer(data=hasnewstype_data)
            hasnewstype_serializer.is_valid(raise_exception=True)
            hasnewstype_serializer.save()

            response.data = {
                'message': 'success',
                'email': request.data['email']
            }
        else:
            response.data = {
                'message': 'Can not add user to post. User is already in post.'
            }

        return response


class DeletePostView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'p_id': openapi.Schema(type=openapi.TYPE_INTEGER),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING)
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        p_id = request.data['p_id']

        user = User.objects.filter(id=payload['id']).first()
        userserializer = UserSerializer(user)
        userrights = hasItemRights.objects.filter(email=userserializer.data['id'], p_id=p_id).first()
        user_rights_item_serializer = UserRightsItemSerializer(userrights)

        response = Response()

        if user_rights_item_serializer.data['r_id'] == 1:
            post = Post.objects.get(p_id=p_id)
            post.delete()

            response.data = {
                'message': 'success'
            }
        else:
            response.data = {
                'message': 'u can`t delete this Post'
            }

        return response


class CreatePaymentView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'name': openapi.Schema(type=openapi.TYPE_STRING),
            'amount': openapi.Schema(type=openapi.TYPE_NUMBER),
            'description': openapi.Schema(type=openapi.TYPE_STRING),
            'email': openapi.Schema(type=openapi.TYPE_STRING)
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'p_id': openapi.Schema(type=openapi.TYPE_INTEGER),
                'name': openapi.Schema(type=openapi.TYPE_STRING),
                'amount': openapi.Schema(type=openapi.TYPE_NUMBER),
                'description': openapi.Schema(type=openapi.TYPE_STRING),
                'creation_date': openapi.Schema(type=openapi.TYPE_STRING)
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        post_data = {
            'name': "Payment",
            'amount': request.data['amount'],
            'description': "Payment",
            'creation_date': datetime.date.today()
        }

        post_serializer = PostSerializer(data=post_data)
        post_serializer.is_valid(raise_exception=True)
        post_serializer.save()
        p_id = post_serializer.data['p_id']

        # user 1
        user_rights_item_data = {
            "email": payload['id'],
            "p_id": p_id,
            "r_id": 1
        }
        user_rights_item_serializer = UserRightsItemSerializer(data=user_rights_item_data)
        user_rights_item_serializer.is_valid(raise_exception=True)
        user_rights_item_serializer.save()

        # user 2
        # get id of second user
        user2 = User.objects.filter(email=request.data['email']).first()
        user2_serializer = UserSerializer(user2)

        user2_rights_item_data = {
            "email": user2_serializer.data['id'],
            "p_id": p_id,
            "r_id": 2
        }
        user2_rights_item_serializer = UserRightsItemSerializer(data=user2_rights_item_data)
        user2_rights_item_serializer.is_valid(raise_exception=True)
        user2_rights_item_serializer.save()

        # ====
        # creating new news for user
        max_n_id = News.objects.all().aggregate(Max('n_id'))['n_id__max']
        if max_n_id is None:
            next_n_id = 1
        else:
            next_n_id = max_n_id + 1

        data = {'n_id': next_n_id}
        news_serializer = NewsSerializer(data=data)
        news_serializer.is_valid(raise_exception=True)
        news_serializer.save()

        n_id = News.objects.get(pk=news_serializer.data['n_id']).n_id

        # add to hasUserNews
        email = user2_serializer.data['id']
        hasusernews_data = {
            "n_id": n_id,
            "email": email,
        }

        hasusernews_serializer = hasUserNewsSerializer(data=hasusernews_data)
        hasusernews_serializer.is_valid(raise_exception=True)
        hasusernews_serializer.save()

        # add to isPostNews
        ispostnews_data = {
            "n_id": n_id,
            "p_id": p_id,
        }
        ispostnews_serializer = isPostNewsSerializer(data=ispostnews_data)
        ispostnews_serializer.is_valid(raise_exception=True)
        ispostnews_serializer.save()

        # add hasNewsType
        # news type 2 == payment
        nt_id = 2
        hasnewstype_data = {
            'nt_id': nt_id,
            'n_id': n_id,
        }
        hasnewstype_serializer = hasNewsTypeSerializer(data=hasnewstype_data)
        hasnewstype_serializer.is_valid(raise_exception=True)
        hasnewstype_serializer.save()
        # ====

        response = Response()
        response.data = {
            'p_id': p_id,
            'name': request.data['name'],
            'amount': request.data['amount'],
            'description': request.data['description'],
            'creation_date': datetime.date.today()
        }
        return response


class GetAllPaymentsView(APIView):
    def get(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        response = Response()
        response.data = {}

        post_dataset = hasItemRights.objects.all().filter(email=payload['id'])
        post_list = []
        for post_data in post_dataset:
            user_rights_item_serializer = UserRightsItemSerializer(post_data)
            post_list.append(user_rights_item_serializer.data['p_id'])

        owns_dataset = Owns.objects.all()
        owns_list = []
        for owns_data in owns_dataset:
            owns_serializer = OwnsSerializer(owns_data)
            owns_list.append(owns_serializer.data['p_id'])

        results = list(set(post_list) - set(owns_list))

        for result in results:
            post = Post.objects.get(p_id=result)
            postserializer = PostSerializer(post)
            p_id = postserializer.data['p_id']
            p_name = postserializer.data['name']
            p_amount = postserializer.data['amount']
            p_description = postserializer.data['description']
            p_creation_date = postserializer.data['creation_date']

            p_admin = hasItemRights.objects.get(p_id=p_id, r_id=1)
            p_admin_serializer = UserRightsItemSerializer(p_admin)
            p_admim_user = User.objects.get(id=p_admin_serializer.data['email'])
            p_admim_serializer = UserSerializer(p_admim_user)

            response.data[p_id] = {'name': p_name}
            response.data[p_id].update({'amount': p_amount})
            response.data[p_id].update({'description': p_description})
            response.data[p_id].update({'creation_date': p_creation_date})
            response.data[p_id].update({'admin': p_admim_serializer.data['email']})
            response.data[p_id].update({'Teilnehmer': {}})

            user_item_dataset = hasItemRights.objects.all().filter(p_id=p_id)
            for user_item in user_item_dataset:
                user_rights_item_serializer = UserRightsItemSerializer(user_item)
                user_serializer = UserSerializer(
                    User.objects.filter(id=user_rights_item_serializer.data['email']).first())
                email = user_serializer.data['email']
                username = user_serializer.data['username']
                response.data[p_id]['Teilnehmer'].update({email: username})
        return response


class GetAllEventsView(APIView):
    def get(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        response = Response()
        response.data = {}

        event_dataset = hasEventRights.objects.all().filter(email=payload['id'])

        for event_data in event_dataset:
            user_rights_event_serializer = UserRightsEventSerializer(event_data)
            v_id = user_rights_event_serializer.data['v_id']
            event_serializer = EventSerializer(Event.objects.get(v_id=v_id))
            v_name = event_serializer.data['name']
            v_due_date = event_serializer.data['due_date']
            v_done = event_serializer.data['done']

            response.data[v_id] = {'name': v_name}
            response.data[v_id].update({'done': v_done})
            response.data[v_id].update({'due_date': v_due_date})

            v_admin = hasEventRights.objects.get(v_id=v_id, r_id=1)
            v_admin_serializer = UserRightsEventSerializer(v_admin)
            v_admim_user = User.objects.get(id=v_admin_serializer.data['email'])
            v_admim_serializer = UserSerializer(v_admim_user)
            response.data[v_id].update({'admin': v_admim_serializer.data['email']})

            response.data[v_id].update({'Teilnehmer': {}})

            user_event_dataset = hasEventRights.objects.all().filter(v_id=v_id)

            for user_data in user_event_dataset:
                user_rights_event_serializer = UserRightsEventSerializer(user_data)
                user_serializer = UserSerializer(
                    User.objects.filter(id=user_rights_event_serializer.data['email']).first())
                email = user_serializer.data['email']
                username = user_serializer.data['username']
                response.data[v_id]['Teilnehmer'].update({email: username})

            response.data[v_id].update({'Posts': {}})
            post_data_set = Owns.objects.all().filter(v_id=v_id)
            for post_data in post_data_set:
                ownserializer = OwnsSerializer(post_data)

                p_id = ownserializer.data['p_id']
                post = Post.objects.get(p_id=p_id)
                postserializer = PostSerializer(post)
                p_name = postserializer.data['name']
                p_amount = postserializer.data['amount']
                p_description = postserializer.data['description']
                p_creation_date = postserializer.data['creation_date']

                p_admin = hasItemRights.objects.get(p_id=p_id, r_id=1)
                p_admin_serializer = UserRightsItemSerializer(p_admin)
                p_admim_user = User.objects.get(id=p_admin_serializer.data['email'])
                p_admim_serializer = UserSerializer(p_admim_user)

                response.data[v_id]['Posts'].update({p_id: {}})
                response.data[v_id]['Posts'][p_id].update({'name': p_name})
                response.data[v_id]['Posts'][p_id].update({'amount': p_amount})
                response.data[v_id]['Posts'][p_id].update({'description': p_description})
                response.data[v_id]['Posts'][p_id].update({'creation_date': p_creation_date})
                response.data[v_id]['Posts'][p_id].update({'admin': p_admim_serializer.data['email']})
                response.data[v_id]['Posts'][p_id].update({'Teilnehmer': {}})

                user_item_dataset = hasItemRights.objects.all().filter(p_id=p_id)
                for user_item in user_item_dataset:
                    user_rights_item_serializer = UserRightsItemSerializer(user_item)
                    user_serializer = UserSerializer(
                        User.objects.filter(id=user_rights_item_serializer.data['email']).first())
                    email = user_serializer.data['email']
                    username = user_serializer.data['username']
                    response.data[v_id]['Posts'][p_id]['Teilnehmer'].update({email: username})

        return response


class GetUserNewsView(APIView):
    def get(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        response = Response()
        response.data = {}

        # get news ids for user
        hasusernews_dataset = hasUserNews.objects.all().filter(email=payload['id'])
        # get each news type
        for usernews in hasusernews_dataset:
            hasusernews_serializer = hasUserNewsSerializer(usernews)

            n_id = hasusernews_serializer.data['n_id']
            email = hasusernews_serializer.data['email']

            response.data[n_id] = {'email': email}
            # get news type
            hasnewstype_serializer = hasNewsTypeSerializer(
                hasNewsType.objects.filter(n_id=n_id).first()
            )

            # get event id (if possible)
            iseventnews_serializer = isEventNewsSerializer(
                isEventNews.objects.filter(n_id=n_id).first()
            )

            # get post id (if possible)
            ispostnews_serializer = isPostNewsSerializer(
                isPostNews.objects.filter(n_id=n_id).first()
            )

            # get v_id for p_id
            owns_serializer = OwnsSerializer(
                Owns.objects.filter(p_id=ispostnews_serializer.data['p_id']).first()
            )

            # create response
            response.data[n_id] = {
                'type': hasnewstype_serializer.data['nt_id'],
                'v_id': iseventnews_serializer.data['v_id'],
                'p_id': ispostnews_serializer.data['p_id'],
                'v_id_for_p_id': owns_serializer.data['v_id']
            }

        return response


class DeleteNewsView(APIView):
    @swagger_auto_schema(request_body=openapi.Schema(
        type=openapi.TYPE_OBJECT,
        properties={
            'n_id': openapi.Schema(type=openapi.TYPE_INTEGER),
        }
    ), responses={'200': openapi.Response(
        description='',
        examples={
            'application/json': {
                'message': openapi.Schema(type=openapi.TYPE_STRING),
            }
        }
    )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')

        n_id = request.data['n_id']

        news = News.objects.get(n_id=n_id)
        news.delete()

        response = Response()

        existing_news = News.objects.filter(n_id=n_id).first()
        if not existing_news:
            response.data = {
                'message': 'success'
            }
        else:
            response.data = {
                'message': 'failed to delete'
            }

        return response


class SetProfilePictureView(APIView):
    parser_classes = [MultiPartParser, FormParser]

    @swagger_auto_schema(request_body=ImageSerializer,
                         responses={'200': openapi.Response(
                             description='',
                             examples={
                                 'application/json': {
                                     'message': openapi.Schema(type=openapi.TYPE_STRING),
                                 }
                             }
                         )})
    def post(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        image_serializer = ImageSerializer(data=request.data)
        image_serializer.is_valid(raise_exception=True)
        image_serializer.save()

        user = User.objects.filter(id=payload['id']).first()
        user.i_id = Image(i_id=image_serializer.data['i_id'])
        user.save()

        response = Response()
        response.data = {
            'message': 'uploaded image successfully'
        }
        return response


class GetProfilePictureView(APIView):
    parser_classes = [MultiPartParser, FormParser]

    @swagger_auto_schema(
        responses={'200': openapi.Response(
            description='',
            examples={
                'application/json': {
                    'image': openapi.Schema(type=openapi.TYPE_OBJECT),
                }
            }
        )})
    def get(self, request):
        token = request.COOKIES.get('jwt')
        if not token:
            raise AuthenticationFailed('Unauthenticaded!')
        try:
            payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        except jwt.ExpiredSignatureError:
            raise AuthenticationFailed('Unauthenticaded second time!')

        user = User.objects.filter(id=payload['id']).first()
        user_serializer = UserSerializer(user)
        i_id = user_serializer.data['i_id']
        image = Image.objects.filter(i_id=i_id).first()

        image_serializer = ImageSerializer(image)

        response = Response()
        response.data = {
            'image': image_serializer.data['image']
        }
        return response
